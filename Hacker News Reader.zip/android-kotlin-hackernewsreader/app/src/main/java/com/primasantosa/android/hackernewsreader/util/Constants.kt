package com.primasantosa.android.hackernewsreader.util

const val BASE_URL = "https://hacker-news.firebaseio.com/"
const val FAVORITE_STORY = 400